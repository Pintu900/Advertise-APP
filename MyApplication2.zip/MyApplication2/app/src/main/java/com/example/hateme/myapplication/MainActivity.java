package com.example.hateme.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private AdView mAdView;
    private InterstitialAd minter;
    private TextView t1;
    private TextView t2;
    private int a = 0;
    private int b = 0;

    public static final String SHARED_PREFS = "sharedprefs";
    public static final String TEXT = "text";
    public static final String INT = "int";
    private String text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MobileAds.initialize(this, "ca-app-pub-8226955812226258~7747480625");

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView = findViewById(R.id.adView1);
        AdRequest adRequest1 = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest1);

        mAdView = findViewById(R.id.adView2);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest2);
        t1 = (TextView) findViewById(R.id.textview);
        t2 = (TextView) findViewById(R.id.textview1);
        loadData();
        updateViews();

        minter = new InterstitialAd(this);
        minter.setAdUnitId("ca-app-pub-8226955812226258/7334025699");
        minter.loadAd(new AdRequest.Builder().build());

        minter.setAdListener(new AdListener()
        {
            @Override
            public void onAdClosed() {
                t1.setText(Integer.toString(a));
                Toast.makeText(MainActivity.this,"ad closed",Toast.LENGTH_SHORT).show();
                minter.loadAd(new AdRequest.Builder().build());
            }
        }
        );

    }
    public void game(View view) {

        if (minter.isLoaded()) {
            minter.show();
            a++;
            b++;
            t1.setText(Integer.toString(a));
            t2.setText(Integer.toString(b));
        }else {
            t2.setText(Integer.toString(b));
            t1.setText(Integer.toString(a));
            Toast.makeText(MainActivity.this,"ad closed",Toast.LENGTH_SHORT).show();
        }
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEXT,t1.getText().toString());
        editor.putInt(INT,a);
        editor.apply();
    }
    public void loadData(){
        SharedPreferences sharedPreferences =getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        text=sharedPreferences.getString(TEXT,"0");
        a = sharedPreferences.getInt(INT,0);
    }
    public void updateViews(){
        t1.setText(text);
    }
}

